# Napp
## An App for Student-Staff Interaction
This app can be used by the students to express their commonly faced problems in the premises of a college campus.
Other students can view the problems faced by the student who has "Posted" the problem with the Photograph of it.
Eg. A Leaking Tap.

## Feature of UpVoting
Students can confirm a particular problem and "Upvote" a problem so that the problem will be noticed by the Grievance committee
and they can prioritize the problems and solve the problems at an easy way.

## Cross Platform
The students can use the Napp android app to submit the grievances, wheras the grievances can be viewed by the grievance committee members
through a flask web application which is official. This is the admin account. It will be authenticated with username and password

## Tools Used
1. Android Studio (Java)
2. Flask Application (Python)
3. Firebase Realtime Database
4. Firebase Authentication
5. Firebase Storage

